package com.farmersmart.kisan

import android.Manifest
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity(), BluetoothClassicManager.BluetoothListener {

    private lateinit var btManager: BluetoothClassicManager
    private lateinit var notifHelper: NotificationHelper

    private var isHindi: Boolean = true
    private var lastSensorData: SensorData = SensorData()

    // UI View References
    private lateinit var tvAppName: TextView
    private lateinit var tvTagline: TextView
    private lateinit var tvBtDevice: TextView
    private lateinit var tvBtStatus: TextView
    private lateinit var btnConnect: Button
    private lateinit var btnDisconnect: Button

    private lateinit var tvMotorTitle: TextView
    private lateinit var tvMotorState: TextView
    private lateinit var btnMotorOn: Button
    private lateinit var btnMotorOff: Button

    private lateinit var tvSensorsTitle: TextView
    private lateinit var lblSoil: TextView
    private lateinit var tvSoilVal: TextView
    private lateinit var tvSoilStatus: TextView

    private lateinit var lblRain: TextView
    private lateinit var tvRainVal: TextView
    private lateinit var tvRainIntensity: TextView

    private lateinit var lblHumidity: TextView
    private lateinit var tvHumidityVal: TextView
    private lateinit var tvTempMini: TextView

    private lateinit var lblLeaf: TextView
    private lateinit var tvLeafVal: TextView
    private lateinit var tvLeafStatus: TextView

    private lateinit var btnLangToggle: Button

    // Permission request launcher
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val btGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions[Manifest.permission.BLUETOOTH_CONNECT] == true
        } else {
            true
        }

        if (btGranted) {
            btManager.connectToKisanRain()
        } else {
            Toast.makeText(
                this,
                if (isHindi) "ब्लूटूथ अनुमति आवश्यक है" else "Bluetooth permission is required",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btManager = BluetoothClassicManager(this)
        btManager.setListener(this)

        notifHelper = NotificationHelper(this)

        initViews()
        setupListeners()
        updateLanguageViews()
    }

    private fun initViews() {
        tvAppName = findViewById(R.id.tvAppName)
        tvTagline = findViewById(R.id.tvTagline)
        tvBtDevice = findViewById(R.id.tvBtDevice)
        tvBtStatus = findViewById(R.id.tvBtStatus)
        btnConnect = findViewById(R.id.btnConnect)
        btnDisconnect = findViewById(R.id.btnDisconnect)

        tvMotorTitle = findViewById(R.id.tvMotorTitle)
        tvMotorState = findViewById(R.id.tvMotorState)
        btnMotorOn = findViewById(R.id.btnMotorOn)
        btnMotorOff = findViewById(R.id.btnMotorOff)

        tvSensorsTitle = findViewById(R.id.tvSensorsTitle)
        lblSoil = findViewById(R.id.lblSoil)
        tvSoilVal = findViewById(R.id.tvSoilVal)
        tvSoilStatus = findViewById(R.id.tvSoilStatus)

        lblRain = findViewById(R.id.lblRain)
        tvRainVal = findViewById(R.id.tvRainVal)
        tvRainIntensity = findViewById(R.id.tvRainIntensity)

        lblHumidity = findViewById(R.id.lblHumidity)
        tvHumidityVal = findViewById(R.id.tvHumidityVal)
        tvTempMini = findViewById(R.id.tvTempMini)

        lblLeaf = findViewById(R.id.lblLeaf)
        tvLeafVal = findViewById(R.id.tvLeafVal)
        tvLeafStatus = findViewById(R.id.tvLeafStatus)

        btnLangToggle = findViewById(R.id.btnLangToggle)
    }

    private fun setupListeners() {
        btnConnect.setOnClickListener {
            checkAndRequestPermissionsThenConnect()
        }

        btnDisconnect.setOnClickListener {
            btManager.disconnect()
        }

        btnMotorOn.setOnClickListener {
            showPreStartSafetyWarningDialog()
        }

        btnMotorOff.setOnClickListener {
            if (btManager.isConnected()) {
                val success = btManager.sendMotorOff()
                if (success) {
                    notifHelper.showMotorStateAlert(false, isHindi)
                    tvMotorState.text = if (isHindi) "मोटर बंद है (STOPPED)" else "Motor is STOPPED"
                    tvMotorState.setTextColor(ContextCompat.getColor(this, R.color.motor_off_red))
                }
            } else {
                showToast(if (isHindi) "कृपया पहले ब्लूटूथ कनेक्ट करें" else "Please connect Bluetooth first")
            }
        }

        btnLangToggle.setOnClickListener {
            isHindi = !isHindi
            updateLanguageViews()
        }
    }

    private fun checkAndRequestPermissionsThenConnect() {
        val permissionsToRequest = mutableListOf<String>()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_CONNECT)
            }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.BLUETOOTH_SCAN)
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                permissionsToRequest.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        if (permissionsToRequest.isEmpty()) {
            btManager.connectToKisanRain()
        } else {
            requestPermissionLauncher.launch(permissionsToRequest.toTypedArray())
        }
    }

    /**
     * Safety warning modal before starting motor
     */
    private fun showPreStartSafetyWarningDialog() {
        val title = if (isHindi) "मोटर सुरक्षा जाँच" else "Pre-Start Safety Checklist"
        val message = if (isHindi)
            "कृपया पुष्टि करें:\n1. 220V/3-फेज वोल्टेज स्थिर है?\n2. डिलीवरी लाइन/फुव्वारा वाल्व खुला है?\n3. कुएं में पर्याप्त पानी है (ड्राई रन सुरक्षा)?"
        else
            "Please confirm before starting:\n1. Is voltage stable (220V/3-Phase)?\n2. Is delivery pipeline valve open?\n3. Is water level adequate (Dry run check)?"

        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(if (isHindi) "हाँ, मोटर चालू करें" else "Confirm & Start") { _, _ ->
                if (btManager.isConnected()) {
                    val success = btManager.sendMotorOn()
                    if (success) {
                        notifHelper.showMotorStateAlert(true, isHindi)
                        tvMotorState.text = if (isHindi) "मोटर चालू है (RUNNING)" else "Motor is RUNNING"
                        tvMotorState.setTextColor(ContextCompat.getColor(this, R.color.motor_on_green))
                    }
                } else {
                    showToast(if (isHindi) "कृपया पहले ब्लूटूथ कनेक्ट करें" else "Please connect Bluetooth first")
                }
            }
            .setNegativeButton(if (isHindi) "रद्द करें" else "Cancel", null)
            .show()
    }

    private fun updateLanguageViews() {
        btnLangToggle.text = if (isHindi) "English" else "हिंदी"

        tvAppName.text = if (isHindi) "किसान स्मार्ट" else "Farmer Smart"
        tvTagline.text = if (isHindi) "स्मार्ट कृषि एवं मोटर नियंत्रण" else "Smart Agriculture & Motor Control"
        tvBtDevice.text = if (isHindi) "डिवाइस: किसान रेन (ESP32)" else "Device: Kisan Rain (ESP32)"

        btnConnect.text = if (isHindi) "कनेक्ट करें" else "Connect"
        btnDisconnect.text = if (isHindi) "डिस्कनेक्ट करें" else "Disconnect"

        tvMotorTitle.text = if (isHindi) "मोटर रिमोट नियंत्रण" else "Motor Remote Control"
        btnMotorOn.text = if (isHindi) "मोटर चालू करें" else "START MOTOR"
        btnMotorOff.text = if (isHindi) "मोटर बंद करें" else "STOP MOTOR"

        tvSensorsTitle.text = if (isHindi) "खेत सेंसर आंकड़े" else "Field Sensor Readings"
        lblSoil.text = if (isHindi) "मिट्टी की नमी" else "Soil Moisture"
        lblRain.text = if (isHindi) "बारिश सेंसर" else "Rain Sensor"
        lblHumidity.text = if (isHindi) "हवा में नमी" else "Air Humidity"
        lblLeaf.text = if (isHindi) "पत्तियों की नमी" else "Leaf Moisture"

        renderSensorData(lastSensorData)
    }

    private fun renderSensorData(data: SensorData) {
        lastSensorData = data

        // Soil
        tvSoilVal.text = "${data.soilMoisture}%"
        tvSoilStatus.text = when {
            data.soilMoisture < 30 -> if (isHindi) "सूखा (सिंचाई आवश्यक)" else "Dry (Irrigate)"
            data.soilMoisture <= 70 -> if (isHindi) "उत्तम नमी" else "Optimal"
            else -> if (isHindi) "अत्यधिक पानी" else "Waterlogged"
        }

        // Rain
        if (data.rainDetected) {
            tvRainVal.text = if (isHindi) "बारिश हो रही है" else "Rain Detected"
            tvRainVal.setTextColor(ContextCompat.getColor(this, R.color.motor_off_red))
            tvRainIntensity.text = "${data.rainIntensity}%"
        } else {
            tvRainVal.text = if (isHindi) "सूखा (कोई बारिश नहीं)" else "Dry (No Rain)"
            tvRainVal.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
            tvRainIntensity.text = "0%"
        }

        // Humidity & Temp
        tvHumidityVal.text = "${data.humidity}%"
        tvTempMini.text = "${data.temperature} °C"

        // Leaf Moisture
        tvLeafVal.text = "${data.leafMoisture}%"
        tvLeafStatus.text = if (data.leafMoisture > 50) {
            if (isHindi) "गीली पत्तियां (फंगस का ध्यान रखें)" else "Wet Foliage (Fungus Risk)"
        } else {
            if (isHindi) "सूखी एवं सुरक्षित" else "Dry & Safe"
        }

        // Motor State
        if (data.isMotorOn) {
            tvMotorState.text = if (isHindi) "मोटर चालू है (RUNNING)" else "Motor is RUNNING"
            tvMotorState.setTextColor(ContextCompat.getColor(this, R.color.motor_on_green))
        } else {
            tvMotorState.text = if (isHindi) "मोटर बंद है (STOPPED)" else "Motor is STOPPED"
            tvMotorState.setTextColor(ContextCompat.getColor(this, R.color.motor_off_red))
        }
    }

    // Bluetooth Classic Listener Callbacks
    override fun onStateChanged(state: BluetoothClassicManager.ConnectionState, message: String) {
        when (state) {
            BluetoothClassicManager.ConnectionState.CONNECTED -> {
                tvBtStatus.text = if (isHindi) "कनेक्टेड (सक्रिय)" else "Connected"
                tvBtStatus.setTextColor(ContextCompat.getColor(this, R.color.motor_on_green))
                showToast(message)
            }
            BluetoothClassicManager.ConnectionState.CONNECTING -> {
                tvBtStatus.text = if (isHindi) "कनेक्ट हो रहा है..." else "Connecting..."
                tvBtStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_gold))
            }
            BluetoothClassicManager.ConnectionState.DISCONNECTED -> {
                tvBtStatus.text = if (isHindi) "डिस्कनेक्टेड" else "Disconnected"
                tvBtStatus.setTextColor(ContextCompat.getColor(this, R.color.motor_off_red))
            }
            BluetoothClassicManager.ConnectionState.ERROR -> {
                tvBtStatus.text = if (isHindi) "त्रुटि" else "Error"
                tvBtStatus.setTextColor(ContextCompat.getColor(this, R.color.motor_off_red))
                showToast(message)
            }
        }
    }

    override fun onDataReceived(data: SensorData) {
        // Automatic Rain Alert
        if (data.rainDetected && !lastSensorData.rainDetected) {
            notifHelper.showRainAlert(isHindi)
        }

        // Automatic Low Soil Moisture Alert
        if (data.soilMoisture < 30 && lastSensorData.soilMoisture >= 30) {
            notifHelper.showLowSoilAlert(data.soilMoisture, isHindi)
        }

        renderSensorData(data)
    }

    override fun onRawPacket(packet: String) {
        // Telemetry stream packet logged
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        btManager.disconnect()
    }
}
