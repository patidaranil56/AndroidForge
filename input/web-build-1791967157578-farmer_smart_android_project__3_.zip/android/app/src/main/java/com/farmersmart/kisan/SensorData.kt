package com.farmersmart.kisan

/**
 * Data model for live farm sensor readings parsed from ESP32 "Kisan Rain"
 */
data class SensorData(
    val soilMoisture: Int = 0,        // 0 - 100%
    val rainDetected: Boolean = false, // True if raining
    val rainIntensity: Int = 0,       // 0 - 100%
    val temperature: Float = 28.5f,   // Ambient °C
    val humidity: Int = 60,           // Relative humidity %
    val leafMoisture: Int = 15,       // Foliage wetness %
    val isMotorOn: Boolean = false,   // Relay state
    val timestamp: Long = System.currentTimeMillis()
)
