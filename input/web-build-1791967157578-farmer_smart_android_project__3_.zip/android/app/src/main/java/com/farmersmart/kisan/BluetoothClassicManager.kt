package com.farmersmart.kisan

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID

/**
 * Native Android Bluetooth Classic (SPP) Manager
 * Communicates with ESP32 device running BluetoothSerial library ("Kisan Rain")
 */
class BluetoothClassicManager(private val context: Context) {

    companion object {
        private const val TAG = "FarmerSmartBT"
        // Standard Serial Port Profile (SPP) UUID used by ESP32 BluetoothSerial
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        const val TARGET_DEVICE_NAME = "Kisan Rain"
    }

    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    private var bluetoothSocket: BluetoothSocket? = null
    private var outputStream: OutputStream? = null
    private var connectedThread: ConnectedReadThread? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    enum class ConnectionState {
        DISCONNECTED,
        CONNECTING,
        CONNECTED,
        ERROR
    }

    interface BluetoothListener {
        fun onStateChanged(state: ConnectionState, message: String)
        fun onDataReceived(data: SensorData)
        fun onRawPacket(packet: String)
    }

    private var listener: BluetoothListener? = null

    fun setListener(listener: BluetoothListener) {
        this.listener = listener
    }

    fun isBluetoothSupported(): Boolean = bluetoothAdapter != null

    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    fun isConnected(): Boolean = bluetoothSocket?.isConnected == true

    @SuppressLint("MissingPermission")
    fun connectToKisanRain() {
        if (!isBluetoothSupported()) {
            notifyState(ConnectionState.ERROR, "Bluetooth hardware is not supported on this device")
            return
        }

        if (!isBluetoothEnabled()) {
            notifyState(ConnectionState.ERROR, "Please turn on Bluetooth in your phone settings")
            return
        }

        notifyState(ConnectionState.CONNECTING, "Searching for '$TARGET_DEVICE_NAME'...")

        Thread {
            try {
                // Step 1: Look through already bonded (paired) devices
                val pairedDevices: Set<BluetoothDevice>? = bluetoothAdapter?.bondedDevices
                var targetDevice: BluetoothDevice? = pairedDevices?.firstOrNull { it.name == TARGET_DEVICE_NAME }

                // Step 2: Fallback search for any device containing "Kisan"
                if (targetDevice == null) {
                    targetDevice = pairedDevices?.firstOrNull { it.name?.contains("Kisan", ignoreCase = true) == true }
                }

                if (targetDevice == null) {
                    notifyState(
                        ConnectionState.ERROR,
                        "Device '$TARGET_DEVICE_NAME' not found in paired devices. Please pair it in Android Bluetooth settings first."
                    )
                    return@Thread
                }

                // Step 3: Connect RFCOMM SPP Socket
                notifyState(ConnectionState.CONNECTING, "Connecting to ${targetDevice.name}...")
                bluetoothAdapter?.cancelDiscovery()

                val socket = targetDevice.createRfcommSocketToServiceRecord(SPP_UUID)
                socket.connect()

                bluetoothSocket = socket
                outputStream = socket.outputStream

                // Step 4: Start background reading thread
                connectedThread = ConnectedReadThread(socket).apply { start() }

                notifyState(ConnectionState.CONNECTED, "Connected to ${targetDevice.name}")

            } catch (e: Exception) {
                Log.e(TAG, "Connection failed", e)
                closeSocket()
                notifyState(ConnectionState.ERROR, "Connection failed: ${e.localizedMessage ?: "Unknown error"}")
            }
        }.start()
    }

    fun disconnect() {
        closeSocket()
        notifyState(ConnectionState.DISCONNECTED, "Disconnected")
    }

    fun sendMotorOn(): Boolean = sendCommand("MOTOR_ON\n")

    fun sendMotorOff(): Boolean = sendCommand("MOTOR_OFF\n")

    fun sendCommand(command: String): Boolean {
        return try {
            outputStream?.write(command.toByteArray(Charsets.UTF_8))
            outputStream?.flush()
            Log.d(TAG, "Sent command: $command")
            true
        } catch (e: IOException) {
            Log.e(TAG, "Failed to send command", e)
            false
        }
    }

    private fun closeSocket() {
        try {
            connectedThread?.cancel()
            connectedThread = null
            bluetoothSocket?.close()
            bluetoothSocket = null
            outputStream = null
        } catch (e: Exception) {
            Log.e(TAG, "Error closing socket", e)
        }
    }

    private fun notifyState(state: ConnectionState, message: String) {
        mainHandler.post {
            listener?.onStateChanged(state, message)
        }
    }

    /**
     * Background thread to continuously read incoming sensor stream from ESP32
     */
    private inner class ConnectedReadThread(private val socket: BluetoothSocket) : Thread() {
        private var isRunning = true
        private val reader = BufferedReader(InputStreamReader(socket.inputStream))

        override fun run() {
            while (isRunning) {
                try {
                    val line = reader.readLine() ?: break
                    if (line.isNotBlank()) {
                        mainHandler.post {
                            listener?.onRawPacket(line)
                            parseSensorPacket(line)
                        }
                    }
                } catch (e: IOException) {
                    if (isRunning) {
                        Log.e(TAG, "Socket read error, device disconnected", e)
                        closeSocket()
                        notifyState(ConnectionState.DISCONNECTED, "Device disconnected")
                    }
                    break
                }
            }
        }

        fun cancel() {
            isRunning = false
            try {
                reader.close()
            } catch (_: Exception) {}
        }
    }

    /**
     * Parses JSON or CSV telemetry packets from ESP32
     */
    private fun parseSensorPacket(raw: String) {
        val trimmed = raw.trim()
        try {
            // Case 1: JSON format
            if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
                val json = JSONObject(trimmed)
                val data = SensorData(
                    soilMoisture = json.optInt("soil", 40),
                    rainDetected = json.optInt("rain", 0) == 1 || json.optBoolean("rain", false),
                    rainIntensity = json.optInt("intensity", if (json.optInt("rain", 0) == 1) 80 else 0),
                    temperature = json.optDouble("temp", 28.5).toFloat(),
                    humidity = json.optInt("hum", 60),
                    leafMoisture = json.optInt("leaf", 15),
                    isMotorOn = json.optInt("motor", 0) == 1 || json.optBoolean("motor", false)
                )
                listener?.onDataReceived(data)
                return
            }

            // Case 2: Key-value CSV format: SOIL:42,RAIN:1,TEMP:28.5,HUM:60,LEAF:15,MOTOR:0
            val parts = trimmed.split(",")
            var soil = 40
            var rain = false
            var temp = 28.5f
            var hum = 60
            var leaf = 15
            var motor = false

            for (part in parts) {
                val kv = part.split(":")
                if (kv.size == 2) {
                    val key = kv[0].trim().uppercase()
                    val value = kv[1].trim()
                    when (key) {
                        "SOIL" -> soil = value.toIntOrNull() ?: soil
                        "RAIN" -> rain = value == "1" || value.equals("true", ignoreCase = true)
                        "TEMP" -> temp = value.toFloatOrNull() ?: temp
                        "HUM" -> hum = value.toIntOrNull() ?: hum
                        "LEAF" -> leaf = value.toIntOrNull() ?: leaf
                        "MOTOR" -> motor = value == "1" || value.equals("on", ignoreCase = true)
                    }
                }
            }

            val data = SensorData(
                soilMoisture = soil,
                rainDetected = rain,
                rainIntensity = if (rain) 85 else 0,
                temperature = temp,
                humidity = hum,
                leafMoisture = leaf,
                isMotorOn = motor
            )
            listener?.onDataReceived(data)

        } catch (e: Exception) {
            Log.w(TAG, "Error parsing sensor packet: $raw", e)
        }
    }
}
