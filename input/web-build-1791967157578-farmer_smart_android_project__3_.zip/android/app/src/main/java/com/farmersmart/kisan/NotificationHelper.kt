package com.farmersmart.kisan

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Handles native Android notifications for automatic rain alerts,
 * low soil moisture warnings, and motor status.
 */
class NotificationHelper(private val context: Context) {

    companion object {
        const val CHANNEL_ID = "farmer_smart_alerts"
        const val CHANNEL_NAME = "Farmer Smart Agricultural Alerts"
        private const val NOTIF_ID_RAIN = 1001
        private const val NOTIF_ID_SOIL = 1002
        private const val NOTIF_ID_MOTOR = 1003

        private var lastRainAlertTime: Long = 0
        private var lastSoilAlertTime: Long = 0
    }

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    init {
        createNotificationChannel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                CHANNEL_NAME,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Critical farm alerts for rain detection and motor state"
                enableVibration(true)
                vibrationPattern = longArrayOf(100, 200, 100, 300)
            }
            notificationManager.createNotificationChannel(channel)
        }
    }

    /**
     * Trigger Automatic Rain Alert
     */
    fun showRainAlert(isHindi: Boolean) {
        val now = System.currentTimeMillis()
        if (now - lastRainAlertTime < 30_000) return // Throttle identical alerts by 30 seconds
        lastRainAlertTime = now

        val title = if (isHindi) "🌧️ सावधान: खेत में बारिश शुरू!" else "🌧️ Rain Detected in Field!"
        val message = if (isHindi)
            "प्राकृतिक वर्षा से पानी मिल रहा है। तुरंत मोटर बंद करने की सलाह दी जाती है।"
        else
            "Natural rainfall detected. Consider turning off irrigation motor to conserve water."

        showNotification(NOTIF_ID_RAIN, title, message)
    }

    /**
     * Trigger Low Soil Moisture Warning
     */
    fun showLowSoilAlert(moisture: Int, isHindi: Boolean) {
        val now = System.currentTimeMillis()
        if (now - lastSoilAlertTime < 30_000) return
        lastSoilAlertTime = now

        val title = if (isHindi) "🏜️ मिट्टी में नमी कम है!" else "🏜️ Low Soil Moisture Alert!"
        val message = if (isHindi)
            "नमी केवल $moisture% रह गई है। फसलों की सिंचाई शुरू करने की आवश्यकता है।"
        else
            "Soil moisture dropped to $moisture%. Irrigation recommended."

        showNotification(NOTIF_ID_SOIL, title, message)
    }

    /**
     * Trigger Motor State Change Notification
     */
    fun showMotorStateAlert(isMotorOn: Boolean, isHindi: Boolean) {
        val title = if (isMotorOn) {
            if (isHindi) "⚡ मोटर चालू कर दी गई है" else "⚡ Irrigation Motor Started"
        } else {
            if (isHindi) "⏹️ मोटर बंद कर दी गई है" else "⏹️ Irrigation Motor Stopped"
        }

        val message = if (isMotorOn) {
            if (isHindi) "पंप चल रहा है, जल प्रवाह सामान्य है।" else "Pump is running, delivery line active."
        } else {
            if (isHindi) "पंप बंद कर दिया गया है।" else "Pump has been turned off safely."
        }

        showNotification(NOTIF_ID_MOTOR, title, message)
    }

    private fun showNotification(id: Int, title: String, message: String) {
        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setSound(soundUri)
            .setVibrate(longArrayOf(100, 200, 100, 300))
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)

        notificationManager.notify(id, builder.build())
    }
}
