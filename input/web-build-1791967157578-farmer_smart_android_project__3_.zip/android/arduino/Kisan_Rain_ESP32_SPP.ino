/*
  ====================================================================
   किसान स्मार्ट (Farmer Smart) - ESP32 Bluetooth Classic (SPP) Firmware
   डिवाइस नाम: "Kisan Rain"
   लाइब्रेरी: BluetoothSerial.h (ESP32 Built-in SPP Profile)
   बिना Wi-Fi या इंटरनेट के ऑफलाइन कार्य हेतु
  ====================================================================
*/

#include "BluetoothSerial.h"
#include <DHT.h>

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error Bluetooth is not enabled! Please run make menuconfig to enable it
#endif

BluetoothSerial SerialBT;

// --- पिन असाइनमेंट (ESP32 Pinout) ---
#define PIN_MOTOR_RELAY     26  // रिले मॉड्यूल पिन (स्टार्टर ऑन/ऑफ)
#define PIN_SOIL_ANALOG     32  // कैपेसिटिव सॉयल मॉइस्चर सेंसर (Analog ADC1)
#define PIN_RAIN_DIGITAL    34  // रेन सेंसर डिजिटल पिन (बारिश संसूचक)
#define PIN_RAIN_ANALOG     35  // रेन सेंसर एनालॉग पिन (वर्षा तीव्रता)
#define PIN_LEAF_MOISTURE   33  // लीफ वेटनेस सेंसर (पत्तियों की नमी)
#define PIN_DHT             4   // DHT22 तापमान एवं आर्द्रता सेंसर
#define DHTTYPE             DHT22

DHT dht(PIN_DHT, DHTTYPE);

bool isMotorOn = false;
unsigned long lastTelemetryTime = 0;
const unsigned long TELEMETRY_INTERVAL_MS = 3000; // हर 3 सेकंड में टेलीमेट्री प्रसारण

void setup() {
  Serial.begin(115200);
  Serial.println("Farmer Smart ESP32 Starting...");

  // पिन मोड सेटअप
  pinMode(PIN_MOTOR_RELAY, OUTPUT);
  digitalWrite(PIN_MOTOR_RELAY, LOW); // प्रारंभ में मोटर बंद रहेगी

  pinMode(PIN_RAIN_DIGITAL, INPUT);
  pinMode(PIN_RAIN_ANALOG, INPUT);
  pinMode(PIN_SOIL_ANALOG, INPUT);
  pinMode(PIN_LEAF_MOISTURE, INPUT);

  dht.begin();

  // Bluetooth Classic SPP इनिशियलाइज़
  // डिवाइस नाम: "Kisan Rain"
  if (!SerialBT.begin("Kisan Rain")) {
    Serial.println("An error occurred initializing Bluetooth Serial");
  } else {
    Serial.println("Bluetooth Classic (SPP) Ready! Device: 'Kisan Rain'");
    Serial.println("Android फोन से 'Kisan Rain' पेयर करें और कनेक्ट करें।");
  }
}

void loop() {
  // 1. Android ऐप से कमांड प्राप्त करना (MOTOR_ON / MOTOR_OFF)
  if (SerialBT.available()) {
    String command = SerialBT.readStringUntil('\n');
    command.trim();
    Serial.print("Received Command: ");
    Serial.println(command);

    if (command.equalsIgnoreCase("MOTOR_ON")) {
      isMotorOn = true;
      digitalWrite(PIN_MOTOR_RELAY, HIGH); // रिले ऑन (स्टार्टर चालू)
      SerialBT.println("+MOTOR_STATUS:1");
      Serial.println(">> Motor Turned ON");
    } else if (command.equalsIgnoreCase("MOTOR_OFF")) {
      isMotorOn = false;
      digitalWrite(PIN_MOTOR_RELAY, LOW); // रिले ऑफ (स्टार्टर बंद)
      SerialBT.println("+MOTOR_STATUS:0");
      Serial.println(">> Motor Turned OFF");
    }
  }

  // 2. हर 3 सेकंड में सेंसर डेटा टेलीमेट्री भेजना
  unsigned long now = millis();
  if (now - lastTelemetryTime >= TELEMETRY_INTERVAL_MS) {
    lastTelemetryTime = now;

    // मिट्टी की नमी (0-100%)
    int rawSoil = analogRead(PIN_SOIL_ANALOG);
    int soilMoisture = map(rawSoil, 3200, 1400, 0, 100);
    soilMoisture = constrain(soilMoisture, 0, 100);

    // बारिश सेंसर
    int rainDigital = digitalRead(PIN_RAIN_DIGITAL);
    int rawRainAnalog = analogRead(PIN_RAIN_ANALOG);
    bool rainDetected = (rainDigital == LOW) || (rawRainAnalog < 2800);
    int rainIntensity = map(rawRainAnalog, 4095, 1000, 0, 100);
    rainIntensity = constrain(rainIntensity, 0, 100);

    // तापमान एवं हवा की नमी
    float temp = dht.readTemperature();
    float hum = dht.readHumidity();
    if (isnan(temp)) temp = 28.5;
    if (isnan(hum)) hum = 60.0;

    // पत्तियों की नमी
    int rawLeaf = analogRead(PIN_LEAF_MOISTURE);
    int leafMoisture = map(rawLeaf, 4095, 1200, 0, 100);
    leafMoisture = constrain(leafMoisture, 0, 100);

    // JSON पैकेट तैयार करें
    String telemetryJson = "{";
    telemetryJson += "\"soil\":" + String(soilMoisture) + ",";
    telemetryJson += "\"rain\":" + String(rainDetected ? 1 : 0) + ",";
    telemetryJson += "\"intensity\":" + String(rainIntensity) + ",";
    telemetryJson += "\"temp\":" + String(temp, 1) + ",";
    telemetryJson += "\"hum\":" + String((int)hum) + ",";
    telemetryJson += "\"leaf\":" + String(leafMoisture) + ",";
    telemetryJson += "\"motor\":" + String(isMotorOn ? 1 : 0);
    telemetryJson += "}\n";

    Serial.print("Sending Telemetry: ");
    Serial.print(telemetryJson);

    // यदि ब्लूटूथ से फोन जुड़ा है तो डेटा भेजें
    if (SerialBT.hasClient()) {
      SerialBT.print(telemetryJson);
    }
  }

  delay(20);
}
